import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ send: vi.fn(), getSignedUrl: vi.fn() }));

vi.mock("@aws-sdk/client-s3", () => ({
  S3Client: class { send = mocks.send; },
  PutObjectCommand: class { constructor(public input: Record<string, unknown>) {} },
  GetObjectCommand: class { constructor(public input: Record<string, unknown>) {} },
}));
vi.mock("@aws-sdk/s3-request-presigner", () => ({ getSignedUrl: mocks.getSignedUrl }));

import { storageGetSignedUrl, storagePut } from "./storage";

const externalStorageEnvironment = {
  STORAGE_S3_BUCKET: "axe-dispatch-test",
  STORAGE_S3_ACCESS_KEY_ID: "test-key",
  STORAGE_S3_SECRET_ACCESS_KEY: "test-secret",
  STORAGE_S3_ENDPOINT: "http://minio.test:9000",
  STORAGE_S3_REGION: "us-east-1",
  STORAGE_S3_FORCE_PATH_STYLE: "true",
};

beforeEach(() => {
  Object.assign(process.env, externalStorageEnvironment);
  mocks.send.mockResolvedValue({});
  mocks.getSignedUrl.mockResolvedValue("https://minio.test/signed-object");
});
afterEach(() => {
  for (const key of Object.keys(externalStorageEnvironment)) delete process.env[key];
  vi.clearAllMocks();
});

describe("armazenamento S3 externo", () => {
  it("envia arquivos ao bucket compatível e mantém a URL interna do aplicativo", async () => {
    const result = await storagePut("profile-photos/9/avatar.png", Buffer.from("imagem"), "image/png");
    expect(result.url).toMatch(/^\/manus-storage\/profile-photos\/9\/avatar_[a-f0-9]{8}\.png$/);
    expect(mocks.send).toHaveBeenCalledWith(expect.objectContaining({ input: expect.objectContaining({ Bucket: "axe-dispatch-test", ContentType: "image/png" }) }));
  });

  it("gera URL temporária para o proxy de download", async () => {
    await expect(storageGetSignedUrl("incident-evidence/1/foto.jpg")).resolves.toBe("https://minio.test/signed-object");
    expect(mocks.getSignedUrl).toHaveBeenCalledWith(expect.anything(), expect.objectContaining({ input: expect.objectContaining({ Bucket: "axe-dispatch-test", Key: "incident-evidence/1/foto.jpg" }) }), { expiresIn: 900 });
  });
});
