/**
 * GOOGLE MAPS FRONTEND INTEGRATION - ESSENTIAL GUIDE
 *
 * USAGE FROM PARENT COMPONENT:
 * ======
 *
 * const mapRef = useRef<google.maps.Map | null>(null);
 *
 * <MapView
 *   initialCenter={{ lat: 40.7128, lng: -74.0060 }}
 *   initialZoom={15}
 *   onMapReady={(map) => {
 *     mapRef.current = map; // Store to control map from parent anytime, google map itself is in charge of the re-rendering, not react state.
 * </MapView>
 *
 * ======
 * Available Libraries and Core Features:
 * -------------------------------
 * 📍 MARKER (from `marker` library)
 * - Attaches to map using { map, position }
 * new google.maps.marker.AdvancedMarkerElement({
 *   map,
 *   position: { lat: 37.7749, lng: -122.4194 },
 *   title: "San Francisco",
 * });
 *
 * -------------------------------
 * 🏢 PLACES (from `places` library)
 * - Does not attach directly to map; use data with your map manually.
 * const place = new google.maps.places.Place({ id: PLACE_ID });
 * await place.fetchFields({ fields: ["displayName", "location"] });
 * map.setCenter(place.location);
 * new google.maps.marker.AdvancedMarkerElement({ map, position: place.location });
 *
 * -------------------------------
 * 🧭 GEOCODER (from `geocoding` library)
 * - Standalone service; manually apply results to map.
 * const geocoder = new google.maps.Geocoder();
 * geocoder.geocode({ address: "New York" }, (results, status) => {
 *   if (status === "OK" && results[0]) {
 *     map.setCenter(results[0].geometry.location);
 *     new google.maps.marker.AdvancedMarkerElement({
 *       map,
 *       position: results[0].geometry.location,
 *     });
 *   }
 * });
 *
 * -------------------------------
 * 📐 GEOMETRY (from `geometry` library)
 * - Pure utility functions; not attached to map.
 * const dist = google.maps.geometry.spherical.computeDistanceBetween(p1, p2);
 *
 * -------------------------------
 * 🛣️ ROUTES (from `routes` library)
 * - Combines DirectionsService (standalone) + DirectionsRenderer (map-attached)
 * const directionsService = new google.maps.DirectionsService();
 * const directionsRenderer = new google.maps.DirectionsRenderer({ map });
 * directionsService.route(
 *   { origin, destination, travelMode: "DRIVING" },
 *   (res, status) => status === "OK" && directionsRenderer.setDirections(res)
 * );
 *
 * -------------------------------
 * 🌦️ MAP LAYERS (attach directly to map)
 * - new google.maps.TrafficLayer().setMap(map);
 * - new google.maps.TransitLayer().setMap(map);
 * - new google.maps.BicyclingLayer().setMap(map);
 *
 * -------------------------------
 * ✅ SUMMARY
 * - “map-attached” → AdvancedMarkerElement, DirectionsRenderer, Layers.
 * - “standalone” → Geocoder, DirectionsService, DistanceMatrixService, ElevationService.
 * - “data-only” → Place, Geometry utilities.
 */

/// <reference types="@types/google.maps" />

import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

declare global {
  interface Window {
    google?: typeof google;
  }
}

const API_KEY = import.meta.env.VITE_FRONTEND_FORGE_API_KEY;
const FORGE_BASE_URL =
  import.meta.env.VITE_FRONTEND_FORGE_API_URL ||
  "https://forge.butterfly-effect.dev";
const MAPS_PROXY_URL = `${FORGE_BASE_URL}/v1/maps/proxy`;
const MAPS_SCRIPT_ID = "axe-dispatch-google-maps-sdk";
let mapsSdkPromise: Promise<void> | null = null;

function loadMapScript() {
  if (window.google?.maps) return Promise.resolve();
  if (mapsSdkPromise) return mapsSdkPromise;
  mapsSdkPromise = new Promise<void>((resolve, reject) => {
    const existingScript = document.getElementById(MAPS_SCRIPT_ID) as HTMLScriptElement | null;
    if (existingScript) {
      existingScript.addEventListener("load", () => resolve(), { once: true });
      existingScript.addEventListener("error", () => reject(new Error("Falha ao carregar o SDK de mapas.")), { once: true });
      return;
    }
    const script = document.createElement("script");
    script.id = MAPS_SCRIPT_ID;
    script.src = `${MAPS_PROXY_URL}/maps/api/js?key=${API_KEY}&v=weekly&loading=async&libraries=marker,places,geocoding,geometry`;
    script.async = true;
    script.crossOrigin = "anonymous";
    script.onload = () => resolve();
    script.onerror = () => {
      mapsSdkPromise = null;
      reject(new Error("Falha ao carregar o SDK de mapas."));
    };
    document.head.appendChild(script);
  });
  return mapsSdkPromise;
}

export function canInitializeMap(input: { cancelled: boolean; hasContainer: boolean; hasMapsApi: boolean }) {
  return !input.cancelled && input.hasContainer && input.hasMapsApi;
}

interface MapViewProps {
  className?: string;
  initialCenter?: google.maps.LatLngLiteral;
  initialZoom?: number;
  mapTypeId?: google.maps.MapTypeId | string;
  trafficEnabled?: boolean;
  onMapReady?: (map: google.maps.Map) => void;
  onMapError?: (error: Error) => void;
}

export function MapView({
  className,
  initialCenter = { lat: 37.7749, lng: -122.4194 },
  initialZoom = 12,
  mapTypeId = "roadmap",
  trafficEnabled = false,
  onMapReady,
  onMapError,
}: MapViewProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<google.maps.Map | null>(null);
  const initializationId = useRef(0);
  const latestProps = useRef({ initialCenter, initialZoom, mapTypeId, trafficEnabled, onMapReady, onMapError });
  latestProps.current = { initialCenter, initialZoom, mapTypeId, trafficEnabled, onMapReady, onMapError };

  useEffect(() => {
    let cancelled = false;
    const currentInitializationId = ++initializationId.current;
    const initialize = async () => {
      try {
        await loadMapScript();
        const current = latestProps.current;
        const hasMapsApi = Boolean(window.google?.maps);
        if (!canInitializeMap({ cancelled: cancelled || currentInitializationId !== initializationId.current, hasContainer: Boolean(mapContainer.current), hasMapsApi })) return;
        map.current = new window.google.maps.Map(mapContainer.current!, {
          zoom: current.initialZoom,
          center: current.initialCenter,
          mapTypeControl: true,
          fullscreenControl: true,
          zoomControl: true,
          streetViewControl: true,
          mapId: "DEMO_MAP_ID",
          mapTypeId: current.mapTypeId,
        });
        if (current.trafficEnabled) new window.google.maps.TrafficLayer().setMap(map.current);
        current.onMapReady?.(map.current);
      } catch (error) {
        if (!cancelled) latestProps.current.onMapError?.(error instanceof Error ? error : new Error("Falha ao carregar o SDK de mapas."));
      }
    };
    void initialize();
    return () => {
      cancelled = true;
      initializationId.current += 1;
      map.current = null;
    };
  }, []);

  return (
    <div ref={mapContainer} className={cn("w-full h-[500px]", className)} />
  );
}
